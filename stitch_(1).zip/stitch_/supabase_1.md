# دليل وكود التشغيل الفوري والربط السحابي مع Supabase
## منصة مستر أشرف السقا - الإدارة المالية والأكاديمية السحابية

بمجرد إنشاء مشروع جديد على **Supabase** (وهو مجاني بالكامل)، كل ما عليك فعله هو تنفيذ الخطوتين التاليتين:

---

### 1️⃣ الخطوة الأولى: نسخ كود الـ SQL وإنشاء الجداول فوراً (Copy & Run in SQL Editor)
افتح مشروعك في [Supabase](https://supabase.com)، اذهب إلى قائمة **SQL Editor** من اليسار، انقر على **New query**، الصق الكود التالي واضغط **Run**:

```sql
-- 1. جدول الكورسات والمقررات
CREATE TABLE IF NOT EXISTS courses (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    title TEXT NOT NULL,
    grade_level TEXT NOT NULL,
    price NUMERIC(10, 2) NOT NULL DEFAULT 800.00,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- إدراج الكورسات الافتراضية
INSERT INTO courses (title, grade_level, price) VALUES
('مراجعة الكيمياء العضوية المكثفة 2025', 'الصف الثالث الثانوي', 800.00),
('الكيمياء الكهربية وقوانين فاراداي', 'الصف الثالث الثانوي', 600.00),
('أساسيات الكيمياء للغات (Chemistry)', 'الصف الأول الثانوي', 500.00)
ON CONFLICT DO NOTHING;

-- 2. جدول الطلاب والاشتراكات
CREATE TABLE IF NOT EXISTS students (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    full_name TEXT NOT NULL,
    student_phone TEXT NOT NULL,
    parent_whatsapp TEXT NOT NULL,
    grade_level TEXT NOT NULL,
    course_name TEXT NOT NULL,
    amount_paid NUMERIC(10, 2) NOT NULL,
    payment_method TEXT NOT NULL,
    activation_code TEXT NOT NULL UNIQUE,
    receipt_url TEXT,
    staff_handler TEXT DEFAULT 'أك. محمود عزت',
    whatsapp_status TEXT DEFAULT 'sent_and_read',
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 3. تفعيل الحماية والوصول المباشر (Row Level Security - RLS)
ALTER TABLE students ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Public Read & Insert for Platform" ON students
    FOR ALL USING (true) WITH CHECK (true);

-- 4. إعداد حاوية تخزين الإيصالات (Storage Bucket)
INSERT INTO storage.buckets (id, name, public) 
VALUES ('receipts-vault', 'receipts-vault', true)
ON CONFLICT (id) DO NOTHING;

CREATE POLICY "Public Access for Receipts" ON storage.objects
    FOR ALL USING (bucket_id = 'receipts-vault') WITH CHECK (bucket_id = 'receipts-vault');
```

---

### 2️⃣ الخطوة الثانية: وضع رابط ومفتاح Supabase في ملف المنظومة (`index.html`)

في شاشة تسجيل الطلاب (`register-student.html` أو `index.html`)، توجد خانتان فقط في بداية الكود:
```javascript
const SUPABASE_URL = "ضع_رابط_المشروع_هنا"; // مثال: https://xyz.supabase.co
const SUPABASE_ANON_KEY = "ضع_المفتاح_العام_anon_key_هنا";
```

بمجرد ملء هاتين الخانتين والضغط على زر:
**«تأكيد الاشتراك وتفعيل حساب المنصة وإرسال الإيصال والجدول للواتساب»**:
1. يتم حفظ الطالب فوراً في قاعدة بيانات Supabase.
2. يظهر كود الطالب فوراً في لوحة التحكم والجدول.
3. يتم إرسال الإشعار لولي الأمر عبر الواتساب تلقائياً.
