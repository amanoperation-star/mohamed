---
name: Royal Academic Finance
colors:
  surface: '#f8f9ff'
  surface-dim: '#cbdbf5'
  surface-bright: '#f8f9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#eff4ff'
  surface-container: '#e5eeff'
  surface-container-high: '#dce9ff'
  surface-container-highest: '#d3e4fe'
  on-surface: '#0b1c30'
  on-surface-variant: '#44474c'
  inverse-surface: '#213145'
  inverse-on-surface: '#eaf1ff'
  outline: '#75777d'
  outline-variant: '#c5c6cd'
  surface-tint: '#525f75'
  primary: '#000000'
  on-primary: '#ffffff'
  primary-container: '#0e1c2f'
  on-primary-container: '#77849c'
  inverse-primary: '#bac7e1'
  secondary: '#426086'
  on-secondary: '#ffffff'
  secondary-container: '#b3d1fd'
  on-secondary-container: '#3b5a7f'
  tertiary: '#735c00'
  on-tertiary: '#ffffff'
  tertiary-container: '#cba72f'
  on-tertiary-container: '#4e3d00'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#d6e3fe'
  primary-fixed-dim: '#bac7e1'
  on-primary-fixed: '#0e1c2f'
  on-primary-fixed-variant: '#3a475c'
  secondary-fixed: '#d3e4ff'
  secondary-fixed-dim: '#aac9f4'
  on-secondary-fixed: '#001c38'
  on-secondary-fixed-variant: '#29486d'
  tertiary-fixed: '#ffe088'
  tertiary-fixed-dim: '#e9c349'
  on-tertiary-fixed: '#241a00'
  on-tertiary-fixed-variant: '#574500'
  background: '#f8f9ff'
  on-background: '#0b1c30'
  surface-variant: '#d3e4fe'
typography:
  headline-xl:
    fontFamily: Cairo
    fontSize: 36px
    fontWeight: '700'
    lineHeight: 48px
  headline-xl-mobile:
    fontFamily: Cairo
    fontSize: 28px
    fontWeight: '700'
    lineHeight: 38px
  headline-lg:
    fontFamily: Cairo
    fontSize: 28px
    fontWeight: '700'
    lineHeight: 40px
  headline-lg-mobile:
    fontFamily: Cairo
    fontSize: 22px
    fontWeight: '700'
    lineHeight: 32px
  headline-md:
    fontFamily: Cairo
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 30px
  body-lg:
    fontFamily: Tajawal
    fontSize: 18px
    fontWeight: '500'
    lineHeight: 28px
  body-md:
    fontFamily: Tajawal
    fontSize: 15px
    fontWeight: '400'
    lineHeight: 24px
  body-sm:
    fontFamily: Tajawal
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 20px
  label-md:
    fontFamily: Tajawal
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
  label-sm:
    fontFamily: Tajawal
    fontSize: 11px
    fontWeight: '700'
    lineHeight: 16px
  numeric-metric:
    fontFamily: Cairo
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 32px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1.25rem
  gutter-mobile: 0.75rem
  margin: 2rem
  margin-mobile: 1rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

## Brand & Style

This design system establishes an authoritative, high-trust administrative and financial experience tailored for the Arabic educational ecosystem. The aesthetic balances **Royal Corporate** prestige with precision-driven fintech clarity, purposefully engineered for an RTL-first cognitive flow.

### Brand Personality & Philosophy
- **Authoritative & Trustworthy:** Anchored by deep regal blues, inspiring confidence for bursars, educators, and executive management handling high-volume student accounts, revenue streams, and academic records.
- **Academic Prestige:** Subtle warm gold accents articulate financial solvency, high-tier status, and institutional excellence without descending into decorative excess.
- **Cognitive Clarity:** High visual discipline ensures that dense rosters, installment tracking, and balance ledgers remain immediately legible and scannable under daily operational stress.

### Design Movement: Modern Executive Neo-Corporate
A hybrid of structured corporate ergonomics, subtle ambient depth, and luminous status indicators. Visual weight is articulated through tonal layering and micro-borders rather than loud ornament, prioritizing data integrity, bi-directional harmony, and seamless Arabic typographic rhythm.

## Colors

The palette leverages a hierarchy rooted in midnight navy, tech steel, academic gold, and distinct financial status indicators.

### Key Roles
- **Primary (`#0B192C`):** Midnight Royal Navy. Used for global navigation headers, high-level structural sidebars, dominant interactive states, and top-tier headings.
- **Secondary (`#1E3E62`):** Executive Slate Blue. Deployed for secondary action buttons, elevated data card headers, table column sorting highlights, and structural dividing containers.
- **Tertiary (`#D4AF37` / `#E5A93C`):** Institutional Imperial Gold. Reserved for financial balance summaries, honors/scholarship indicators, VIP subscription badges, and high-priority revenue alerts.
- **Neutral (`#64748B`):** Cool Slate. Governs supportive meta-data, secondary labels, structural borders (`#E2E8F0`), and soft neutral background tiers (`#F8FAFC` to `#FFFFFF`).

### Functional & Financial Tokens
- **Success (`#10B981`):** Emerald Green for fully cleared tuition payments, active enrollments, and positive revenue trajectories.
- **Danger / Overdue (`#EF4444`):** Crimson Warning for defaulted installments, late fee alerts, suspended student profiles, and critical system anomalies.
- **Surface Foundations:** Primary app background sits at clean `#F8FAFC` to minimize eye strain during long auditing hours, elevating cards at pure `#FFFFFF` with muted slate dividing lines (`#E2E8F0`).

## Typography

Typographic scale is constructed to accommodate the higher baseline and unique proportions of Arabic script. **Cairo** anchors headlines and tabular figures with structured geometry and authority, while **Tajawal** ensures open, flowing legibility for data-dense tables, student records, and complex invoices.

### Typography Rules
- **RTL Baseline Alignment:** Cairo requires deliberate line-height buffering to avoid glyph clipping across diacritics and tall ascenders. Maintain minimum line heights of 1.4x to 1.6x.
- **Tabular Figures for Financials:** All monetary amounts, serial IDs, and academic statistics use Cairo’s tabular digit alignment (`tnum`) to ensure perfect vertical column alignment in audit tables.
- **Weight Pairing:** High-contrast headings (`700 Cairo`) pair with clean, legible medium-weight body (`400`/`500 Tajawal`) to maintain an executive demeanor without cognitive clutter.

## Layout & Spacing

The layout operates on an 8pt architectural rhythm, calibrated for a comprehensive financial dashboard environment.

### Layout Philosophy
- **RTL Fluid Matrix:** A 12-column grid on desktop (1440px+ and 1024px) transitioning to a 4-column system on mobile (<768px). The root flows strictly right-to-left: side navigation pins to the right edge, data visualizers span the center, and contextual action drawers open from the left.
- **Audit Table Constraints:** Dense ledger views deploy unified inner cell gutters (`space-sm` vertical, `space-md` horizontal) to maximize data density while preventing numeric overlap.
- **Section Rhythm:** Administrative modules use `space-xl` separation, keeping KPI performance bars distinct from drill-down transaction tables.

## Elevation & Depth

Visual hierarchy uses low-contrast borders coupled with ultra-diffused navy ambient shadows rather than heavy skeuomorphism. This ensures an airy, premium paper-like surface that keeps high numbers, debt badges, and graphs crisp.

### Elevation Hierarchy
- **Canvas Base (Level 0):** `#F8FAFC`. Zero elevation, pure background container.
- **Surface Tier 1 (Cards, Ledger Containers):** `#FFFFFF` with a 1px perimeter border of `#E2E8F0` and shadow: `0px 2px 8px -2px rgba(11, 25, 44, 0.04), 0px 1px 4px -1px rgba(11, 25, 44, 0.02)`.
- **Surface Tier 2 (Hover States, Floating Financial Summaries):** `#FFFFFF` with shadow: `0px 10px 24px -4px rgba(11, 25, 44, 0.08), 0px 4px 8px -2px rgba(11, 25, 44, 0.03)`.
- **Surface Tier 3 (Modals, Transaction Drawers, Sticky Toolbars):** `#FFFFFF` with a border of `#CBD5E1` and deep ambient shadow: `0px 20px 32px -8px rgba(11, 25, 44, 0.14)`.
- **Financial Status Accents:** Negative balance callouts and critical payment warnings add a 1px inset boundary highlight (`rgba(239, 68, 68, 0.2)`) to intensify immediate recognition.

## Shapes

The design uses balanced, modern corporate roundedness (`Level 2`), conveying high professionalism without looking playful or childish.

### Radius Calibration
- **Standard UI Elements (`0.5rem` / `8px`):** Used for standard buttons, input fields, dropdown triggers, and interactive table rows.
- **Containers & Data Cards (`1rem` / `16px`):** Applied to KPI balance cards, student grade summaries, data table outer containers, and modal sheets.
- **Financial Status Badges & Pills (`9999px`):** Transaction state indicators (e.g., "مسدد بالكامل", "متأخر", "قيد المعالجة") retain a full pill profile to stand distinct from structural containers.

## Components

### Buttons
- **Primary Financial Action:** Solid `#0B192C` fill, `#FFFFFF` text, subtle 1px border of `#1E3E62`. Hover shifts to `#1E3E62` with a discrete gold accent line on bottom or focus ring (`#D4AF37`).
- **Prestige / Action Button:** Solid `#D4AF37` fill, dark navy `#0B192C` bold text, designed for "استلام دفعة" (Collect Payment) or "ترقية الاشتراك".
- **Ghost / Neutral:** Transparent with `#E2E8F0` border and `#1E3E62` typography; scales to light navy tint on hover (`#F1F5F9`).

### Data Tables & Ledgers (Financial-Grade)
- **Header Row:** Crisp `#F8FAFC` background with bold `Cairo` typography (`13px`, `#1E3E62`), equipped with RTL sort indicators on the left edge of cell headers.
- **Rows:** Minimum height of 52px, delimited by 1px horizontal dividers (`#F1F5F9`). Subtle hover elevation tint (`#F8FAFC`).
- **Numeric Alignment:** Arabic numerals and monetary codes (`ج.م` / `EGP`) are strictly right-aligned for Arabic readability, maintaining vertical decimal congruence.

### KPI & Metric Cards
- **Structure:** Clean white surface, 16px radius, featuring a 4px vertical prestige edge or accent indicator.
- **Hierarchy:** Tiny label (`12px Tajawal` in `#64748B`) atop a massive tabular figure (`24px-32px Cairo`), accompanied by an inline status pill displaying percentage movement and directional arrow.

### Input Fields & Search Bars
- **Frame:** `#FFFFFF` background with 1px `#CBD5E1` border, 8px radius, with icon slot positioned on the right (search lens, student ID icon) and contextual action on the left.
- **Focus State:** 2px focus ring tinted in tech slate (`#1E3E62`) with inset clean glow, transitioning border to `#0B192C`.

### Status Badges & Chips
- **Paid / Success:** `#ECFDF5` background, `#065F46` label, and `#10B981` leading dot indicator.
- **Defaulted / Overdue:** `#FEF2F2` background, `#991B1B` label, and `#EF4444` leading indicator.
- **Pending / In Review:** `#FFFBEB` background, `#92400E` label, and `#D4AF37` indicator.

### Checkboxes & Radio Controls
- **Styling:** Custom 20px rounded squares (checkbox) and circles (radio) in `#E2E8F0` border. Active state fills with `#0B192C` displaying a crisp white micro checkmark, optimized for bulk student selection and multi-invoice handling.