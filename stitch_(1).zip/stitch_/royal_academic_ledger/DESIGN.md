---
name: Royal Academic Ledger
colors:
  surface: '#0d141e'
  surface-dim: '#0d141e'
  surface-bright: '#333945'
  surface-container-lowest: '#080e18'
  surface-container-low: '#161c26'
  surface-container: '#1a202a'
  surface-container-high: '#242a35'
  surface-container-highest: '#2f3540'
  on-surface: '#dde2f1'
  on-surface-variant: '#c2c6d6'
  inverse-surface: '#dde2f1'
  inverse-on-surface: '#2b313c'
  outline: '#8c909f'
  outline-variant: '#424754'
  surface-tint: '#adc6ff'
  primary: '#adc6ff'
  on-primary: '#002e6a'
  primary-container: '#4d8eff'
  on-primary-container: '#00285d'
  inverse-primary: '#005ac2'
  secondary: '#7bd0ff'
  on-secondary: '#00354a'
  secondary-container: '#00a6e0'
  on-secondary-container: '#00374d'
  tertiary: '#ffb95f'
  on-tertiary: '#472a00'
  tertiary-container: '#ca8100'
  on-tertiary-container: '#3e2400'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#d8e2ff'
  primary-fixed-dim: '#adc6ff'
  on-primary-fixed: '#001a42'
  on-primary-fixed-variant: '#004395'
  secondary-fixed: '#c4e7ff'
  secondary-fixed-dim: '#7bd0ff'
  on-secondary-fixed: '#001e2c'
  on-secondary-fixed-variant: '#004c69'
  tertiary-fixed: '#ffddb8'
  tertiary-fixed-dim: '#ffb95f'
  on-tertiary-fixed: '#2a1700'
  on-tertiary-fixed-variant: '#653e00'
  background: '#0d141e'
  on-background: '#dde2f1'
  surface-variant: '#2f3540'
typography:
  display-hero:
    fontFamily: Newsreader
    fontSize: 48px
    fontWeight: '500'
    lineHeight: 56px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Newsreader
    fontSize: 36px
    fontWeight: '600'
    lineHeight: 44px
    letterSpacing: -0.015em
  headline-lg-mobile:
    fontFamily: Newsreader
    fontSize: 28px
    fontWeight: '600'
    lineHeight: 36px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Newsreader
    fontSize: 24px
    fontWeight: '500'
    lineHeight: 32px
  headline-sm:
    fontFamily: Newsreader
    fontSize: 20px
    fontWeight: '500'
    lineHeight: 28px
  body-lg:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  body-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
  label-numeric-lg:
    fontFamily: JetBrains Mono
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 24px
    letterSpacing: -0.02em
  label-numeric-md:
    fontFamily: JetBrains Mono
    fontSize: 14px
    fontWeight: '500'
    lineHeight: 18px
  label-tag:
    fontFamily: Inter
    fontSize: 11px
    fontWeight: '600'
    lineHeight: 14px
    letterSpacing: 0.05em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  gutter: 1.5rem
  gutter-sm: 1rem
  margin: 2rem
  margin-mobile: 1rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2rem
---

## Brand & Style
This design system merges the dignified authority of classical academic institutions with the razor-sharp precision of modern institutional finance. Designed specifically for university bursars, research endowment managers, and executive administrators, the interface projects trust, prestige, and analytical clarity.

The visual direction draws from high-contrast editorial minimalism fused with technical fintech utility. It rejects playful, casual motifs in favor of deliberate structure, disciplined typographic hierarchy, and luminous data callouts. Deep navy tones emulate nighttime academic sanctuaries, while sapphire, amber, and emerald accents provide instantaneous status comprehension without cognitive strain. The UI feels regal yet computational—delivering an atmosphere of architectural depth and uncompromising stability.

## Colors
The palette is rooted in an abyss of midnight navies, layered specifically to structure dense financial figures and academic rosters:

- **Canvas & Surface Base:** The canvas initiates at `#070d17` (Canvas Floor) and steps to `#0b1524` (Sub-canvas / Group Floor).
- **Structural Containers:** Primary cards and elevated panels occupy `#132238`, ascending to `#162a45` for active hover states or elevated modal dialogues.
- **Outlines & Borders:** Subtle boundary control is maintained via `#1e3a5f` (baseline divider/border) and `#2d4f7c` (interactive or focused boundaries).
- **Primary & Secondary Glow:** `#3b82f6` (Royal Cobalt) functions as the interactive baseline for primary commands, focused selections, and chart vectors. `#38bdf8` (Cyan Sheen) serves as the vibrant highlight for telemetry tickers and active link glows.
- **Status Accents:**
  - *Paid / Verified / Endowed:* `#10b981` (Base Emerald) accented by `#34d399` (Vibrant Emerald Glow).
  - *Pending / Audit / Honors:* `#f59e0b` (Golden Amber) reserved for pending disbursement, critical endowments, and alert flags.
  - *Overdue / Deficit:* `#ef4444` for strict financial variances.
- **Typography Tokens:** Content clarity utilizes `#f0f4fc` for primary reading and metrics, `#94a3b8` for metadata and subtitles, and `#475569` for disabled states.

## Typography
The typographic landscape is built on a tripartite hierarchy balancing academic prestige, legible data grids, and tabular financial balance:

1. **Academic Headers (Newsreader):** Brings editorial permanence and stature to page titles, endowment accounts, and institutional statements. Its classical serif curves soften the cold reality of finance.
2. **System Interface & Body (Inter):** Deployed for descriptions, forms, filters, and standard navigational controls. Inter provides neutral, unencumbered readability under low-light configurations.
3. **Ledger Data & Metric Readouts (JetBrains Mono):** Monospaced precision is mandatory for currency readouts, ledger IDs, transactional timestamps, and grade indices, preventing layout shifts when dynamic calculations update live.

Text contrast must never drop below 4.5:1 against the midnight containers. Subheaders and field captions leverage `label-tag` set to uppercase tracking for immediate structural scanning.

## Layout & Spacing
The layout follows a 12-column dynamic fluid grid on desktop viewports (collapsing to an 8-column configuration for tablet dashboards and a 4-column column-stacked flow on mobile viewports).

- **Grid Architecture:** Desktop views maintain a standard `margin` of `2rem` (32px) and an inner column `gutter` of `1.5rem` (24px). Compact viewports adapt `margin-mobile` to `1rem` (16px) with an inner `gutter-sm` of `1rem`.
- **Rhythm & Padding:** All interior component spacing anchors to a strict 4px/8px modular cadence. Nested table headers, form arrays, and telemetry cards maintain uniform `space-md` gaps to retain structure in data-dense layouts.
- **Responsive Handling:** Complex financial ledger tables scroll horizontally with anchored index columns on mobile. Multi-tier administrative sidebars collapse into a permanent icon dock below 1280px widths to prioritize numerical table real estate.

## Elevation & Depth
Depth does not rely on heavy drop-shadows, which muddy dark interfaces. Instead, spatial hierarchy is constructed through luminous tonal layering and focused boundary illumination:

- **Base Layer (Level 0):** Background floor `#070d17`. Completely flat, non-reactive.
- **Segment Layer (Level 1):** Main sections and data grouping panels at `#0b1524`, framed with a 1px baseline border of `#1e3a5f`.
- **Component Layer (Level 2):** Standard interactive cards, tables, and metric modules sit at `#132238`. Elevation is accentuated using an inner top-edge highlight: `box-shadow: inset 0 1px 0 0 rgba(240, 244, 252, 0.05)`.
- **Raised & Modal Layer (Level 3):** Flyouts, dropdown menus, and dialogs inhabit `#162a45`, anchored with a crisp border of `#2d4f7c` and a subtle deep-tinted shadow: `0 12px 32px -4px rgba(2, 6, 12, 0.7)`.
- **Focus & Selection Luminescence:** Active cards and focused interactive controls cast a soft cobalt radiance (`0 0 16px -2px rgba(59, 130, 246, 0.25)`), creating an authoritative optical feedback loop without cluttering the screen.

## Shapes
In line with academic institutional rigor and high-frequency analytical tooling, geometry remains disciplined, compact, and structured. A `roundedness` level of `1` (Soft) is enforced across the platform:

- **Base Components (Buttons, Form Inputs, Badges):** Sculpted with a clean `0.25rem` (4px) corner radius. This prevents the casual, consumer-app appearance associated with large rounded corners and maximizes usable screen space.
- **Card Panels & Data Displays (`rounded-lg`):** Fixed at `0.5rem` (8px). Softens large block boundaries while keeping lines clean and architectural.
- **Modals & Flyouts (`rounded-xl`):** Capped at `0.75rem` (12px), delineating temporary contextual surfaces from the foundational platform grid.

## Components

### Buttons
- **Primary:** Background in `#3b82f6`, text in `#f0f4fc` (weight 600). Top edge features a subtle 1px highlight line (`rgba(255, 255, 255, 0.2)`). Hover transitions to `#2563eb` with a cyan-tinted glow (`box-shadow: 0 0 12px rgba(56, 189, 248, 0.35)`).
- **Secondary / Outline:** Background transparent, 1px border of `#1e3a5f`, text `#f0f4fc`. Hover state adopts background `#132238` and border `#2d4f7c`.
- **Ghost / Tertiary:** No background or border. Text `#94a3b8`, transitioning to `#38bdf8` on hover.

### Status Badges & Chips
- **Structure:** `label-tag` typography with 4px vertical, 8px horizontal padding. Border radius fixed at `0.25rem`.
- **Paid / Cleared:** Background `rgba(16, 185, 129, 0.12)`, border 1px solid `rgba(52, 211, 153, 0.3)`, text `#34d399`. Accompanied by a 6px solid emerald status dot.
- **Pending / In Audit:** Background `rgba(245, 158, 11, 0.12)`, border 1px solid `rgba(245, 158, 11, 0.3)`, text `#f59e0b`.
- **Disputed / Overdue:** Background `rgba(239, 68, 68, 0.12)`, border 1px solid `rgba(239, 68, 68, 0.3)`, text `#f87171`.

### Data Tables & Lists
- Table headers utilize `#0b1524` with uppercase `label-tag` text in `#94a3b8`, separated by a 1px border in `#1e3a5f`.
- Alternating row backgrounds transition between transparent and `rgba(19, 34, 56, 0.4)`. Hover state on table rows illuminates the row with `#162a45` and a left border accent in `#3b82f6`.
- Numerical columns right-align using `label-numeric-md`.

### Form Fields & Inputs
- Container background set to `#070d17` with an inset boundary of `#1e3a5f`. Placeholder text in `#475569`.
- Focused state transitions border to `#38bdf8` with an ambient ring: `0 0 0 1px #38bdf8, 0 0 8px rgba(56, 189, 248, 0.25)`.
- Label typography sits at `body-sm` (weight 500) rendered in `#94a3b8`.

### Checkboxes & Radios
- Size: 16px × 16px square (checkbox) or circle (radio). Base background `#0b1524`, border 1px solid `#2d4f7c`.
- Selected state turns the control into `#3b82f6` with a crisp `#070d17` checkmark/indicator icon, backed by a soft royal glow.

### Cards & Ledger Blocks
- Background `#132238`, wrapped in a crisp 1px `#1e3a5f` border.
- Header bands are partitioned by a horizontal rule using `#1e3a5f`. Metrics display prominent totals using `display-hero` or `label-numeric-lg` paired with a directional indicator arrow in emerald or crimson.